﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlammeRouge
{
    /// <summary>
    /// not yet
    /// this may could be used to replace the player2
    /// </summary>
    internal class Robot
    {
    }
}
