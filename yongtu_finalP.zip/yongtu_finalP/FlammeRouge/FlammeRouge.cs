﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace FlammeRouge
{
    public partial class FlammeRouge : Form
    {
        /// <summary>
        /// Square width
        /// </summary>
        public static int SQUARE_WIDTH = 80;
        /// <summary>z
        /// Square length
        /// </summary>
        public static int SQUARE_LENGTH = 30;
        /// <summary>
        /// The game state
        /// </summary>
        public GameState GameState { get; set; }
        public FlammeRouge()
        {
            InitializeComponent();
            // Create new game
            CreateNewGame();
        }

        /// <summary>
        /// Creare new game
        /// </summary>
        public void CreateNewGame()
        {
            GameState = new GameState();
            // Set the tips message
            string tips = $"The green line is start line and the orange line is finish line.\n" +
                           $"The color of player1 is red and the color of player2 is blue.";
            TipBar.Text = tips;
            NextTurn();
        }

        /// <summary>
        /// Only draw the riders
        /// </summary>
        public void DrawGameState()
        {
            Graphics g = gamePanel.CreateGraphics();
            int xOffset = 10;
            int yOffset = 20;

            // Draw the squares
            for (int i = 0; i < GameState.Track.TrackLength(); i++)
            {
                int x = xOffset + i * SQUARE_LENGTH;
                int y = yOffset;
                DrawOneSquare(g, x, y, i, false);
            }
        }

        /// <summary>
        /// Draw the whole game state
        /// </summary>
        public void DrawCompleteGameState()
        {
            Graphics g = gamePanel.CreateGraphics();
            int xOffset = 10;
            int yOffset = 20;

            // Draw the squares
            for(int i = 0; i < GameState.Track.TrackLength(); i++)
            {
                int x = xOffset + i * SQUARE_LENGTH;
                int y = yOffset;
                DrawOneSquare(g, x, y, i, true);
            }

            // Draw the start line and finish line
            int xPos = xOffset + 4 * SQUARE_LENGTH;
            int yPos = yOffset;
            DrawStartOrFinishLine(true, g, xPos, yPos);
            xPos = xOffset + (GameState.Track.TrackLength() - 4) * SQUARE_LENGTH;
            DrawStartOrFinishLine(false, g, xPos, yPos);
        }

        /// <summary>
        /// Draw one square
        /// </summary>
        /// <param name="g">graphics device</param>
        /// <param name="x">x position</param>
        /// <param name="y">y position</param>
        public void DrawOneSquare(Graphics g, 
            int x, int y, int squareIndex, bool drawLines)
        {
            Pen pen = new Pen(Color.Blue, 2);
            if (drawLines)
            {
                // Draw the square
                for (int i = 0; i < 2; i++)
                {
                    int yOffset = i * SQUARE_WIDTH / 2;
                    g.DrawLine(pen, x, y + yOffset, x + SQUARE_LENGTH, y + yOffset);
                    g.DrawLine(pen, x, y + SQUARE_WIDTH / 2 + yOffset, x + SQUARE_LENGTH, y + SQUARE_WIDTH / 2 + yOffset);
                    g.DrawLine(pen, x, y + yOffset, x, y + SQUARE_WIDTH / 2 + yOffset);
                    g.DrawLine(pen, x + SQUARE_LENGTH, y + yOffset, x + SQUARE_LENGTH, y + SQUARE_WIDTH / 2 + yOffset);
                }
            }
            // Draw the rider in the lanes if needed
            Square square = GameState.Track.Squares[squareIndex];
            if(!square.LeftLane.IsFree())
            {
                Rider rider = square.LeftLane.Rider;
                Player player = rider.Player;
                SolidBrush brush = new SolidBrush(player.PlayerIndex == 0 ? Color.Red: Color.Blue);
                int mx = x + 5;
                int my = y + 5;
                g.FillRectangle(brush, mx, my, SQUARE_LENGTH - 10, SQUARE_WIDTH / 2 - 10);
                brush = new SolidBrush(Color.White);
                g.DrawString(rider.Name, new Font("Serial", 14), brush, mx, my + 2);
            } else
            {
                // Clear the old rider
                SolidBrush brush = new SolidBrush(Color.White);
                int mx = x + 5;
                int my = y + 5;
                g.FillRectangle(brush, mx, my, SQUARE_LENGTH - 10, SQUARE_WIDTH / 2 - 10);
            }
            if (!square.RightLane.IsFree())
            {
                Rider rider = square.RightLane.Rider;
                Player player = rider.Player;
                SolidBrush brush = new SolidBrush(player.PlayerIndex == 0 ? Color.Red : Color.Blue);
                int mx = x + 5;
                int my = y + 5 + SQUARE_WIDTH / 2;
                g.FillRectangle(brush, mx, my, SQUARE_LENGTH - 10, SQUARE_WIDTH / 2 - 10);
                brush = new SolidBrush(Color.White);
                g.DrawString(rider.Name, new Font("Serial", 14), brush, mx, my + 2);
            } else
            {
                // Clear the old rider
                SolidBrush brush = new SolidBrush(Color.White);
                int mx = x + 5;
                int my = y + 5 + SQUARE_WIDTH / 2;
                g.FillRectangle(brush, mx, my, SQUARE_LENGTH - 10, SQUARE_WIDTH / 2 - 10);
            }
        }

        /// <summary>
        /// Draw start line or fish line
        /// </summary>
        /// <param name="startLine">whether it is a start line</param>
        /// <param name="g">graphics device</param>
        /// <param name="x">x position</param>
        /// <param name="y">y position</param>
        public void DrawStartOrFinishLine(bool startLine, Graphics g, int x, int y)
        {
            // Set the line color
            Pen pen;
            if (startLine)
            {
                pen = new Pen(Color.Green, 3);
            } else
            {
                pen = new Pen(Color.Orange, 3);
            }
            // Draw the line
            g.DrawLine(pen, x, y, x, y + SQUARE_WIDTH);
        }

        /// <summary>
        /// Execute the movement pahse
        /// </summary>
        public void MovementPhase()
        {
            GameState.Movement(ActionAfterMovement);
        }

        /// <summary>
        /// Action after moving one rider
        /// </summary>
        /// <param name="seconds">some seconds</param>
        public void ActionAfterMovement(float seconds) {
            DrawGameState();
            Thread.Sleep((int)(seconds * 1000));
        }

        /// <summary>
        /// Execute the end pahse
        /// </summary>
        public void EndPhase()
        {
            // Apply slipstreaming
            GameState.ApplySlipstreaming();
            DrawGameState();
            // Assign exhaustiton cards
            GameState.AssignExhaustionCards();
        }

        /// <summary>
        /// Execute movement phase
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event argument</param>
        private void MoveButton_Click(object sender, EventArgs e)
        {
            MGroupBox.Enabled = false;
            MovementPhase();
            EndGroupBox.Enabled = true;
        }

        /// <summary>
        /// Execute end phase
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event argument</param>
        private void ExecuteButton_Click(object sender, EventArgs e)
        {
            EndGroupBox.Enabled = false;
            EndPhase();
            // Perform the next turn
            NextTurn();
        }

        /// <summary>
        /// This is called when the window is shown in the first time
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event arguments</param>
        private void FlammeRouge_Shown(object sender, EventArgs e)
        {
            DrawCompleteGameState();
        }

        /// <summary>
        /// Sprinteur rider draws the cards
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event argument</param>
        private void DrawSButton_Click(object sender, EventArgs e)
        {
            List<Card> cards = GameState.CurrentPlayer.SprinteurRider.Deck.DrawCards();
            SComboBox.Items.Clear();
            // Add the drawn cards
            for(int i = 0; i < cards.Count; i++)
            {
                SComboBox.Items.Add(cards[i].Value);
            }
            SComboBox.SelectedIndex = 0;
            // Output the status message
            int playerIndex = GameState.CurrentPlayer.PlayerIndex;
            StatusBar.Text += $"Player{playerIndex + 1} drawed four cards for sprinteur rider.\n";
            DrawSButton.Enabled = false;
        }

        /// <summary>
        /// Rouleur rider draws the cards
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event argument</param>
        private void DrawRButton_Click(object sender, EventArgs e)
        {
            List<Card> cards = GameState.CurrentPlayer.RouleurRider.Deck.DrawCards();
            RComboBox.Items.Clear();
            // Add the drawn cards
            for (int i = 0; i < cards.Count; i++)
            {
                RComboBox.Items.Add(cards[i].Value);
            }
            RComboBox.SelectedIndex = 0;
            // Output the status message
            int playerIndex = GameState.CurrentPlayer.PlayerIndex;
            StatusBar.Text += $"Player{playerIndex + 1} drawed four cards for rouleur rider.\n";
            DrawRButton.Enabled = false;
        }

        /// <summary>
        /// Sprinteur rider plays the card
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event argument</param>
        private void PlaySButton_Click(object sender, EventArgs e)
        {
            if(SComboBox.Items.Count == 0)
            {
                return;
            }
            GameState.CurrentPlayer.SprinteurRider.Deck.RecycleCard(int.Parse(SComboBox.Text));
            // Output the status message
            int playerIndex = GameState.CurrentPlayer.PlayerIndex;
            StatusBar.Text += $"Player{playerIndex + 1} played one card with {SComboBox.Text} for sprinteur rider.\n";
            PlaySButton.Enabled = false;
            SComboBox.Items.Clear();
            SComboBox.Text = "";

            GameState.PlayedRiders.Add("S");
            if (GameState.PlayedRiders.Count == 2)
            {
                GameState.PlayedPlayers.Add(GameState.CurrentPlayer.PlayerIndex);
                if (GameState.PlayedPlayers.Count == 2)
                {
                    // Energe phase has been completed
                    EnableEnergePhase();
                    EnergyGroupBox.Enabled = false;
                    MGroupBox.Enabled = true;
                } else
                {
                    // Switch to another player
                    GameState.SwitchPlayer();
                    EnableEnergePhase();
                }
            }
            
        }

        /// <summary>
        /// Rouleur rider plays the card
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">event argument</param>
        private void PlayRButton_Click(object sender, EventArgs e)
        {
            if (RComboBox.Items.Count == 0)
            {
                return;
            }
            GameState.CurrentPlayer.RouleurRider.Deck.RecycleCard(int.Parse(RComboBox.Text));
            // Output the status message
            int playerIndex = GameState.CurrentPlayer.PlayerIndex;
            StatusBar.Text += $"Player{playerIndex + 1} played one card with {RComboBox.Text} for rouleur rider.\n";
            PlayRButton.Enabled = false;
            RComboBox.Items.Clear();
            RComboBox.Text = "";

            GameState.PlayedRiders.Add("R");
            if (GameState.PlayedRiders.Count == 2)
            {
                GameState.PlayedPlayers.Add(GameState.CurrentPlayer.PlayerIndex);
                if (GameState.PlayedPlayers.Count == 2)
                {
                    // Energe phase has been completed
                    EnableEnergePhase();
                    EnergyGroupBox.Enabled = false;
                    MGroupBox.Enabled = true;
                } else
                {
                    // Switch to another player
                    GameState.SwitchPlayer();
                    EnableEnergePhase();
                }
            }
        }

        /// <summary>
        /// Enable the energy pahse
        /// </summary>
        public void EnableEnergePhase()
        {
            EnergyGroupBox.Enabled = true;
            DrawSButton.Enabled = true;
            DrawRButton.Enabled = true;
            PlaySButton.Enabled = true;
            PlayRButton.Enabled = true;
        }

        /// <summary>
        /// Next Turn
        /// </summary>
        public void NextTurn()
        {
            EnergyGroupBox.Enabled = true;
            MGroupBox.Enabled = false;
            EndGroupBox.Enabled = false;
            StatusBar.Text = "";
            GameState.NewTurn();

            // Examine if the game is over
            Player winner = GameState.GetWinner();
            if(winner != null)
            {
                // Show the winner
                StatusBar.Text = $"The game is over and the winner is player {winner.PlayerIndex + 1}";
                EnergyGroupBox.Enabled = false;
            }
        }

        private void TipBar_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
