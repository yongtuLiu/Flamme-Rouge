﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlammeRouge
{
    /// <summary>
    /// It represents a lane in the square
    /// </summary>
    public class Lane
    {
        /// <summary>
        /// Stored rider in the lane
        /// </summary>
        public Rider Rider { get; set; }

        /// <summary>
        /// Whether the lane is free
        /// </summary>
        public bool IsFree()
        {
            return Rider == null;
        }

        /// <summary>
        /// Remove the rider
        /// </summary>
        public void RemoveRider()
        {
            Rider = null;
        }
    }
}
