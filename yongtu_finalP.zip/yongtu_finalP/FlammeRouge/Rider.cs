﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlammeRouge
{
    /// <summary>
    /// It represents a rider
    /// </summary>
    public class Rider
    {
        /// <summary>
        /// The name of the rider
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// The square index
        /// </summary>
        public int SquareIndex { get; set; }
        /// <summary>
        /// The lane index
        /// </summary>
        public int LaneIndex { get; set; }
        /// <summary>
        /// The player which the rider belongs to 
        /// </summary>
        public Player Player { get; set; }
        /// <summary>
        /// The corresponding deck
        /// </summary>
        public Deck Deck {get; set;}

        /// <summary>
        /// Create a rider
        /// </summary>
        /// <param name="name">the naem of the rider</param>
        public Rider(string name)
        {
            Name = name;
        }
    }
}
