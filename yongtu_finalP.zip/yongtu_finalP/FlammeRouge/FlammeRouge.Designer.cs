﻿namespace FlammeRouge
{
    partial class FlammeRouge
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.MoveButton = new System.Windows.Forms.Button();
            this.ExecuteButton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.DrawSButton = new System.Windows.Forms.Button();
            this.PlaySButton = new System.Windows.Forms.Button();
            this.SComboBox = new System.Windows.Forms.ComboBox();
            this.DrawRButton = new System.Windows.Forms.Button();
            this.PlayRButton = new System.Windows.Forms.Button();
            this.RComboBox = new System.Windows.Forms.ComboBox();
            this.EnergyGroupBox = new System.Windows.Forms.GroupBox();
            this.StatusBar = new System.Windows.Forms.RichTextBox();
            this.gamePanel = new System.Windows.Forms.Panel();
            this.MGroupBox = new System.Windows.Forms.GroupBox();
            this.EndGroupBox = new System.Windows.Forms.GroupBox();
            this.TipBar = new System.Windows.Forms.RichTextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.EnergyGroupBox.SuspendLayout();
            this.MGroupBox.SuspendLayout();
            this.EndGroupBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MoveButton
            // 
            this.MoveButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MoveButton.Location = new System.Drawing.Point(96, 112);
            this.MoveButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MoveButton.Name = "MoveButton";
            this.MoveButton.Size = new System.Drawing.Size(144, 51);
            this.MoveButton.TabIndex = 1;
            this.MoveButton.Text = "Move";
            this.MoveButton.UseVisualStyleBackColor = true;
            this.MoveButton.Click += new System.EventHandler(this.MoveButton_Click);
            // 
            // ExecuteButton
            // 
            this.ExecuteButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExecuteButton.Location = new System.Drawing.Point(92, 109);
            this.ExecuteButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ExecuteButton.Name = "ExecuteButton";
            this.ExecuteButton.Size = new System.Drawing.Size(144, 54);
            this.ExecuteButton.TabIndex = 1;
            this.ExecuteButton.Text = "Execute";
            this.ExecuteButton.UseVisualStyleBackColor = true;
            this.ExecuteButton.Click += new System.EventHandler(this.ExecuteButton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(36, 75);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 36);
            this.label7.TabIndex = 0;
            this.label7.Text = "Sprinteur";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(36, 168);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 36);
            this.label8.TabIndex = 0;
            this.label8.Text = "Rouleur";
            // 
            // DrawSButton
            // 
            this.DrawSButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DrawSButton.Location = new System.Drawing.Point(168, 69);
            this.DrawSButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.DrawSButton.Name = "DrawSButton";
            this.DrawSButton.Size = new System.Drawing.Size(144, 53);
            this.DrawSButton.TabIndex = 1;
            this.DrawSButton.Text = "Draw";
            this.DrawSButton.UseVisualStyleBackColor = true;
            this.DrawSButton.Click += new System.EventHandler(this.DrawSButton_Click);
            // 
            // PlaySButton
            // 
            this.PlaySButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlaySButton.Location = new System.Drawing.Point(584, 67);
            this.PlaySButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.PlaySButton.Name = "PlaySButton";
            this.PlaySButton.Size = new System.Drawing.Size(144, 56);
            this.PlaySButton.TabIndex = 1;
            this.PlaySButton.Text = "Play";
            this.PlaySButton.UseVisualStyleBackColor = true;
            this.PlaySButton.Click += new System.EventHandler(this.PlaySButton_Click);
            // 
            // SComboBox
            // 
            this.SComboBox.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SComboBox.FormattingEnabled = true;
            this.SComboBox.Location = new System.Drawing.Point(354, 75);
            this.SComboBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.SComboBox.Name = "SComboBox";
            this.SComboBox.Size = new System.Drawing.Size(180, 41);
            this.SComboBox.TabIndex = 2;
            // 
            // DrawRButton
            // 
            this.DrawRButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DrawRButton.Location = new System.Drawing.Point(166, 162);
            this.DrawRButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.DrawRButton.Name = "DrawRButton";
            this.DrawRButton.Size = new System.Drawing.Size(144, 54);
            this.DrawRButton.TabIndex = 1;
            this.DrawRButton.Text = "Draw";
            this.DrawRButton.UseVisualStyleBackColor = true;
            this.DrawRButton.Click += new System.EventHandler(this.DrawRButton_Click);
            // 
            // PlayRButton
            // 
            this.PlayRButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlayRButton.Location = new System.Drawing.Point(584, 157);
            this.PlayRButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.PlayRButton.Name = "PlayRButton";
            this.PlayRButton.Size = new System.Drawing.Size(144, 56);
            this.PlayRButton.TabIndex = 1;
            this.PlayRButton.Text = "Play";
            this.PlayRButton.UseVisualStyleBackColor = true;
            this.PlayRButton.Click += new System.EventHandler(this.PlayRButton_Click);
            // 
            // RComboBox
            // 
            this.RComboBox.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RComboBox.FormattingEnabled = true;
            this.RComboBox.Location = new System.Drawing.Point(354, 165);
            this.RComboBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RComboBox.Name = "RComboBox";
            this.RComboBox.Size = new System.Drawing.Size(180, 41);
            this.RComboBox.TabIndex = 2;
            // 
            // EnergyGroupBox
            // 
            this.EnergyGroupBox.Controls.Add(this.PlaySButton);
            this.EnergyGroupBox.Controls.Add(this.RComboBox);
            this.EnergyGroupBox.Controls.Add(this.label7);
            this.EnergyGroupBox.Controls.Add(this.SComboBox);
            this.EnergyGroupBox.Controls.Add(this.label8);
            this.EnergyGroupBox.Controls.Add(this.DrawSButton);
            this.EnergyGroupBox.Controls.Add(this.PlayRButton);
            this.EnergyGroupBox.Controls.Add(this.DrawRButton);
            this.EnergyGroupBox.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnergyGroupBox.Location = new System.Drawing.Point(24, 45);
            this.EnergyGroupBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EnergyGroupBox.Name = "EnergyGroupBox";
            this.EnergyGroupBox.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EnergyGroupBox.Size = new System.Drawing.Size(789, 254);
            this.EnergyGroupBox.TabIndex = 3;
            this.EnergyGroupBox.TabStop = false;
            this.EnergyGroupBox.Text = "Energy Phase";
            // 
            // StatusBar
            // 
            this.StatusBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.StatusBar.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatusBar.Location = new System.Drawing.Point(2, 803);
            this.StatusBar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.StatusBar.Name = "StatusBar";
            this.StatusBar.ReadOnly = true;
            this.StatusBar.Size = new System.Drawing.Size(1920, 375);
            this.StatusBar.TabIndex = 4;
            this.StatusBar.Text = "";
            // 
            // gamePanel
            // 
            this.gamePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gamePanel.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gamePanel.Location = new System.Drawing.Point(2, 389);
            this.gamePanel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gamePanel.Name = "gamePanel";
            this.gamePanel.Size = new System.Drawing.Size(1920, 242);
            this.gamePanel.TabIndex = 5;
            // 
            // MGroupBox
            // 
            this.MGroupBox.Controls.Add(this.MoveButton);
            this.MGroupBox.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MGroupBox.Location = new System.Drawing.Point(836, 45);
            this.MGroupBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MGroupBox.Name = "MGroupBox";
            this.MGroupBox.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MGroupBox.Size = new System.Drawing.Size(352, 254);
            this.MGroupBox.TabIndex = 6;
            this.MGroupBox.TabStop = false;
            this.MGroupBox.Text = "Movement Phase";
            // 
            // EndGroupBox
            // 
            this.EndGroupBox.Controls.Add(this.ExecuteButton);
            this.EndGroupBox.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EndGroupBox.Location = new System.Drawing.Point(1227, 45);
            this.EndGroupBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EndGroupBox.Name = "EndGroupBox";
            this.EndGroupBox.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EndGroupBox.Size = new System.Drawing.Size(345, 251);
            this.EndGroupBox.TabIndex = 7;
            this.EndGroupBox.TabStop = false;
            this.EndGroupBox.Text = "End Phase";
            // 
            // TipBar
            // 
            this.TipBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TipBar.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TipBar.Location = new System.Drawing.Point(2, 677);
            this.TipBar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TipBar.Name = "TipBar";
            this.TipBar.ReadOnly = true;
            this.TipBar.Size = new System.Drawing.Size(1920, 98);
            this.TipBar.TabIndex = 4;
            this.TipBar.Text = "";
            this.TipBar.TextChanged += new System.EventHandler(this.TipBar_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 13.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(2, 333);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(1005, 48);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "Red Colour represents Player1, Blue Colour represents Player2!!!";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(1610, 48);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(269, 251);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Robot Player";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(36, 107);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 54);
            this.button1.TabIndex = 1;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FlammeRouge
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1923, 1181);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.EndGroupBox);
            this.Controls.Add(this.MGroupBox);
            this.Controls.Add(this.gamePanel);
            this.Controls.Add(this.TipBar);
            this.Controls.Add(this.StatusBar);
            this.Controls.Add(this.EnergyGroupBox);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FlammeRouge";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Flamme Rouge";
            this.Shown += new System.EventHandler(this.FlammeRouge_Shown);
            this.EnergyGroupBox.ResumeLayout(false);
            this.EnergyGroupBox.PerformLayout();
            this.MGroupBox.ResumeLayout(false);
            this.EndGroupBox.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button MoveButton;
        private System.Windows.Forms.Button ExecuteButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button DrawSButton;
        private System.Windows.Forms.Button PlaySButton;
        private System.Windows.Forms.ComboBox SComboBox;
        private System.Windows.Forms.Button DrawRButton;
        private System.Windows.Forms.Button PlayRButton;
        private System.Windows.Forms.ComboBox RComboBox;
        private System.Windows.Forms.GroupBox EnergyGroupBox;
        private System.Windows.Forms.RichTextBox StatusBar;
        private System.Windows.Forms.Panel gamePanel;
        private System.Windows.Forms.GroupBox MGroupBox;
        private System.Windows.Forms.GroupBox EndGroupBox;
        private System.Windows.Forms.RichTextBox TipBar;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
    }
}

