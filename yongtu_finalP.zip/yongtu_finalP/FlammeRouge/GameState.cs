﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlammeRouge
{
    /// <summary>
    /// It represents the game state
    /// </summary>
    public class GameState
    {
        /// <summary>
        /// Players in the game
        /// </summary>
        public List<Player> Players;
        /// <summary>
        /// The track in the game
        /// </summary>
        public Track Track { get; set; }
        /// <summary>
        /// Current player
        /// </summary>
        public Player CurrentPlayer { get; set; }

        public List<string> PlayedRiders { get; set; }
        public List<int> PlayedPlayers { get; set; }

        /// <summary>
        /// Create the game state
        /// </summary>
        public GameState()
        {
            PlayedRiders = new List<string>();
            PlayedPlayers = new List<int>();
            // Create two players
            Players = new List<Player>();
            Players.Add(new Player(0));
            Players.Add(new Player(1));

            // Create the riders
            Players[0].CreateRiders();
            Players[1].CreateRiders();

            // Create the track
            Track = new Track(26);

            // Place the riders on the track
            Track.PlaceRiderAt(Players[0].SprinteurRider, 3);
            Track.PlaceRiderAt(Players[1].SprinteurRider, 3);
            Track.PlaceRiderAt(Players[1].RouleurRider, 2);
            Track.PlaceRiderAt(Players[0].RouleurRider, 2);

            CurrentPlayer = Players[0];
        }

        /// <summary>
        /// Switch to another player
        /// </summary>
        public void SwitchPlayer()
        {
            if(CurrentPlayer.PlayerIndex == 0)
            {
                CurrentPlayer = Players[1];
            } else
            {
                CurrentPlayer = Players[0];
            }
            PlayedRiders.Clear();
        }

        /// <summary>
        /// New turn
        /// </summary>
        public void NewTurn()
        {
            PlayedRiders.Clear();
            PlayedPlayers.Clear();
            CurrentPlayer = Players[0];
        }

        /// <summary>
        /// Movment pahse
        /// </summary>
        /// <param name="actionFunc">action function</param>
        public void Movement(Action<float> actionFunc)
        {
            // Start from the frontmost rider
            for(int i = Track.TrackLength() - 5; i >= 0; i--)
            {
                Lane leftLane = Track.Squares[i].LeftLane;
                Lane rightLane = Track.Squares[i].RightLane;
                if (!rightLane.IsFree())
                {
                    // Move the rider
                    MoveRider(rightLane, rightLane.Rider, i, 1);
                    actionFunc(1.8f);
                }
                if (!leftLane.IsFree())
                {
                    // Move the rider
                    MoveRider(leftLane, leftLane.Rider, i, 0);
                    actionFunc(1.8f);
                }
            }
        }

        /// <summary>
        /// Move the rider
        /// </summary>
        /// <param name="lane">the lane which has the rider</param>
        /// <param name="rider">the given rider</param>
        /// <param name="squareIndex">square index</param>
        /// <param name="laneIndex">lane index</param>
        public void MoveRider(Lane lane, Rider rider, 
            int squareIndex, int laneIndex)
        {
            Player player = rider.Player;
            int steps = rider.Name == "S" ?
                player.SprinteurRider.Deck.PlayedCardValue :
                player.RouleurRider.Deck.PlayedCardValue;
            // The rider moves the given steps
            bool hasMovement = false;
            int resultSquareIndex = squareIndex;
            for(int i = squareIndex + 1; i < Track.TrackLength() && steps > 0; i++)
            {
                if (Track.Squares[i].HasFreeLane())
                {
                    hasMovement = true;
                    resultSquareIndex = i;
                }
                steps--;
            }
            // Reset the old lane
            if (hasMovement)
            {
                lane.RemoveRider();
                Track.PlaceRiderAt(rider, resultSquareIndex);
            }
        }

        /// <summary>
        /// Get the winner
        /// </summary>
        /// <returns>the winner</returns>
        public Player GetWinner()
        {
            Player winner = null;
            for (int i = Track.TrackLength() - 1; i >= Track.TrackLength() - 4; i--)
            {
                Lane leftLane = Track.Squares[i].LeftLane;
                Lane rightLane = Track.Squares[i].RightLane;
                // Examine if there was one rider which arrived at the finish line
                if (!rightLane.IsFree())
                {
                    winner = rightLane.Rider.Player;
                    break;
                } else if (!leftLane.IsFree())
                {
                    winner = leftLane.Rider.Player;
                    break;
                }
            }
            return winner;
        }

        /// <summary>
        /// Apply slipstreaming
        /// </summary>
        public void ApplySlipstreaming()
        {
            bool hasSlipstreaming = true;
            while (hasSlipstreaming)
            {
                hasSlipstreaming = false;
                // Get the last pack
                int startIdx = -1;
                int endIdx = 0;
                for(int i = 0; i < Track.TrackLength() - 4; i++)
                {
                    if (!Track.Squares[i].IsEmpty())
                    {
                        startIdx = i;
                        break;
                    }
                }
                for (int i = startIdx + 1; i < Track.TrackLength() - 4; i++)
                {
                    if (Track.Squares[i].IsEmpty())
                    {
                        endIdx = i - 1;
                        break;
                    }
                }
                
                if (startIdx >= 0 && endIdx >= startIdx)
                {
                    if(endIdx < Track.TrackLength() - 2 
                        && Track.Squares[endIdx + 1].IsEmpty()
                        && !Track.Squares[endIdx + 2].IsEmpty())
                    {
                        hasSlipstreaming = true;
                    }
                    if (hasSlipstreaming)
                    {
                        // Apply slipstreaming
                        for (int i = endIdx; i >= startIdx; i--)
                        {
                            Track.Squares[i + 1].RightLane.Rider =
                                Track.Squares[i].RightLane.Rider;
                            Track.Squares[i + 1].LeftLane.Rider =
                                Track.Squares[i].LeftLane.Rider;
                        }
                        Track.Squares[startIdx].RightLane.RemoveRider();
                        Track.Squares[startIdx].LeftLane.RemoveRider();
                    }
                }
            }
        }

        /// <summary>
        /// Assign exhaustiton cards
        /// </summary>
        public void AssignExhaustionCards()
        {
            for (int i = 0; i < Track.TrackLength() - 4; i++)
            {
                Square square = Track.Squares[i];
                Lane leftLane = square.LeftLane;
                Lane rightLane = square.RightLane;
                if (!square.IsEmpty())
                {
                    if (Track.Squares[i + 1].IsEmpty())
                    {
                        // Assign exhaustion cards
                        if (!leftLane.IsFree())
                        {
                            string name = leftLane.Rider.Name;
                            Player player = leftLane.Rider.Player;
                            if (name == "S")
                            {
                                player.SprinteurRider.Deck.AddRecycledCard(new ExhaustionCard());
                            }
                            else
                            {
                                player.RouleurRider.Deck.AddRecycledCard(new ExhaustionCard());
                            }
                        }
                        if (!rightLane.IsFree())
                        {
                            string name = rightLane.Rider.Name;
                            Player player = rightLane.Rider.Player;
                            if (name == "S")
                            {
                                player.SprinteurRider.Deck.AddRecycledCard(new ExhaustionCard());
                            }
                            else
                            {
                                player.RouleurRider.Deck.AddRecycledCard(new ExhaustionCard());
                            }
                        }
                    }
                }
            }
        }
    }
}
