﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlammeRouge
{
    /// <summary>
    /// It represents a square in the track
    /// </summary>
    public class Square
    {
        /// <summary>
        /// Left lane
        /// </summary>
        public Lane LeftLane;
        /// <summary>
        /// Right lane
        /// </summary>
        public Lane RightLane;

        /// <summary>
        /// Create a square
        /// </summary>
        public Square()
        {
            LeftLane = new Lane();
            RightLane = new Lane();
        }

        /// <summary>
        /// Whether the square is empty
        /// </summary>
        public bool IsEmpty()
        {
            return LeftLane.Rider == null && RightLane.Rider == null;
        }

        /// <summary>
        /// Whether the square has free lane
        /// </summary>
        public bool HasFreeLane()
        {
            return LeftLane.Rider == null || RightLane.Rider == null;
        }

        /// <summary>
        /// Add one rider in the square
        /// </summary>
        /// <param name="rider">the given square</param>
        public void AddRider(Rider rider)
        {
            if(LeftLane.Rider == null)
            {
                LeftLane.Rider = rider;
            } else if(RightLane.Rider == null)
            {
                RightLane.Rider = rider;
            }
        }
    }
}
