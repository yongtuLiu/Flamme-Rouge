﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlammeRouge
{
    /// <summary>
    /// It represents a card
    /// </summary>
    public class Card
    {
        /// <summary>
        /// The value of the card
        /// </summary>
        public int Value { get; set; }

        /// <summary>
        /// Create a card
        /// </summary>
        /// <param name="value">the value of the card</param>
        public Card(int value)
        {
            Value = value;
        }
    }
}
