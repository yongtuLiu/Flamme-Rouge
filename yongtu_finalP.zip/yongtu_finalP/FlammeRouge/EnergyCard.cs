﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlammeRouge
{
    /// <summary>
    /// It represents energy card
    /// </summary>
    public class EnergyCard : Card
    {
        /// <summary>
        /// Create an energy card
        /// </summary>
        /// <param name="value">the value of the card</param>
        public EnergyCard(int value) : base(value)
        {
        }
    }
}
