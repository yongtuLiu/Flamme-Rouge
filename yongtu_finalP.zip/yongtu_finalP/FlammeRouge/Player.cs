﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlammeRouge
{
    /// <summary>
    /// It represents a player
    /// </summary>
    public class Player
    {
        /// <summary>
        /// Player index
        /// </summary>
        public int PlayerIndex { get; set; }
        /// <summary>
        /// Sprinteur Rider
        /// </summary>
        public Rider SprinteurRider { get; set; }
        /// <summary>
        /// Rouleur Rider
        /// </summary>
        public Rider RouleurRider { get; set; }

        /// <summary>
        /// Player index
        /// </summary>
        /// <param name="index">the index</param>
        public Player(int index)
        {
            PlayerIndex = index;
        }

        /// <summary>
        /// Create riders for the player
        /// </summary>
        public void CreateRiders()
        {
            // Create two riders
            SprinteurRider = new Rider("S");
            RouleurRider = new Rider("R");
            SprinteurRider.Player = this;
            RouleurRider.Player = this;

            // Create the decks for the riders
            SprinteurRider.Deck = new Deck("Sprinteur");
            RouleurRider.Deck = new Deck("Rouleur");
        }
    }
}
