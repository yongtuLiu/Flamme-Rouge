﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlammeRouge
{
    /// <summary>
    /// It represents a deck of cards
    /// </summary>
    public class Deck
    {
        public static Random rd = new Random();
        /// <summary>
        /// The cards in the deck
        /// </summary>
        public List<Card> Cards { get; set; }
        /// <summary>
        /// Recycled cards
        /// </summary>
        public List<Card> RecycledCards { get; set; }
        /// <summary>
        /// Drawn cards
        /// </summary>
        public List<Card> DrawnCards { get; set; }
        /// <summary>
        /// The value of played card
        /// </summary>
        public int PlayedCardValue { get; set; }

        /// <summary>
        /// Create a deck of cards
        /// </summary>
        public Deck(string riderType)
        {
            // get the values of cards
            int[] values;
            if (riderType == "Sprinteur")
            {
                values = new int[] { 2, 3, 4, 5, 9 };
            }
            else
            {
                values = new int[] { 3, 4, 5, 6, 7 };
            }
            // create the cards
            Cards = new List<Card>();
            RecycledCards = new List<Card>();
            for (int i = 0; i < values.Length; i++)
            {
                Cards.Add(new EnergyCard(values[i]));
            }
            // shuffle the cards
            ShuffleCards(Cards);
        }

        /// <summary>
        /// Shuffle the cards
        /// </summary>
        /// <param name="cards">the cards</param>
        private void ShuffleCards(List<Card> cards)
        {
            for (int i = 0; i < 50; i++)
            {
                int j = rd.Next(Cards.Count);
                int k = rd.Next(Cards.Count);
                (Cards[j], Cards[k]) = (Cards[k], Cards[j]);
            }
        }

        /// <summary>
        /// Draw four cards from the deck
        /// </summary>
        /// <returns></returns>
        public List<Card> DrawCards()
        {
            List<Card> cards = new List<Card>();
            Random rd = new Random();
            if(Cards.Count < 4)
            {
                if(RecycledCards.Count == 0)
                {
                    return Cards;
                }
                // Add these cards
                cards.AddRange(Cards);
                Cards.Clear();
                // Use recycled cards
                Cards.AddRange(RecycledCards);
                RecycledCards.Clear();
                ShuffleCards(Cards);
                // Draw more cards
                while(Cards.Count > 0 && cards.Count < 4)
                {
                    Card card = Cards[rd.Next(Cards.Count)];
                    Cards.Remove(card);
                    cards.Add(card);
                }
            } else
            {
                // Drwn four cards from the remaining cards
               for(int i = 0; i < 4; i++)
                {
                    Card card = Cards[rd.Next(Cards.Count)];
                    Cards.Remove(card);
                    cards.Add(card);
                }
            }
            DrawnCards = cards;
            return cards;
        }

        /// <summary>
        /// Recycle the unplayed cards
        /// </summary>
        /// <param name="playedCardValue">the value of played card</param>
        public void RecycleCard(int playedCardValue)
        {
            PlayedCardValue = playedCardValue;
            for(int i = 0; i < DrawnCards.Count; i++)
            {
                if (DrawnCards[i].Value != playedCardValue)
                {
                    // recycle the card
                    RecycledCards.Add(DrawnCards[i]);
                }
            }
            DrawnCards.Clear();
        }

        /// <summary>
        /// Add recycled card
        /// </summary>
        /// <param name="card">the recycled card</param>
        public void AddRecycledCard(Card card)
        {
            RecycledCards.Add(card);
        }
    }
}
