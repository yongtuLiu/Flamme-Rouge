﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlammeRouge
{
    /// <summary>
    /// It represents an exhaustion card
    /// </summary>
    public class ExhaustionCard : Card
    {
        /// <summary>
        /// Create an exhaustion card
        /// </summary>
        /// <param name="value">the value of the card</param>
        public ExhaustionCard() : base(2)
        {
        }
    }
}
