﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlammeRouge
{
    /// <summary>
    /// It represents a track
    /// </summary>
    public class Track
    {
        /// <summary>
        /// Square in the track
        /// </summary>
        public List<Square> Squares { get; set; }

        /// <summary>
        /// Create the track
        /// </summary>
        public Track(int n)
        {
            Squares = new List<Square>();
            for(int i = 0; i < n; i++)
            {
                Squares.Add(new Square());
            }
        }

        /// <summary>
        /// Get the length of the track
        /// </summary>
        /// <returns>the length of the track</returns>
        public int TrackLength()
        {
            return Squares.Count;
        }

        /// <summary>
        /// Place the rider in the given position
        /// </summary>
        /// <param name="rider">the given rider</param>
        /// <param name="squarIndex">square index</param>
        /// <param name="laneIndex">lane index</param>
        public void PlaceRiderAt(Rider rider, int squarIndex, int laneIndex)
        {
            if(laneIndex == 0)
            {
                Squares[squarIndex].LeftLane.Rider = rider;
            } else
            {
                Squares[squarIndex].RightLane.Rider = rider;
            }
        }

        /// <summary>
        /// Place the rider in the given square
        /// </summary>
        /// <param name="rider">the given rider</param>
        /// <param name="squarIndex">square index</param>
        public void PlaceRiderAt(Rider rider, int squarIndex)
        {
            if (!Squares[squarIndex].HasFreeLane())
            {
                return;
            }
            rider.SquareIndex = squarIndex;
            if (Squares[squarIndex].RightLane.IsFree())
            {
                // Place the rider
                Squares[squarIndex].RightLane.Rider = rider;
                rider.LaneIndex = 1;
            }
            else
            {
                // Place the rider
                Squares[squarIndex].LeftLane.Rider = rider;
                rider.LaneIndex = 0;
            }
        }
    }
}
