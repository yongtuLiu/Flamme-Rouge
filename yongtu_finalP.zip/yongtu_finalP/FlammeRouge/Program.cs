﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlammeRouge
{
    internal static class Program
    {
        /// <summary>
        /// Yongtu Liu
        /// 1624366
        /// Here is the main "entrance" for this app
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FlammeRouge());
        }
    }
}
